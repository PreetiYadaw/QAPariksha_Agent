import React, { useState } from 'react';
import { Alert, Box, Button, CircularProgress, IconButton, Paper, TextField, Tooltip, Typography } from '@mui/material';
import { Settings, Lock } from '@mui/icons-material';
import type { User } from '../agent.d';

export const LoginView: React.FC<{
  serverUrl: string;
  version: string;
  notice: string;
  onLoggedIn: (u: User) => void;
  onOpenSettings: () => void;
}> = ({ serverUrl, version, notice, onLoggedIn, onOpenSettings }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password) { setError('Enter your username and password.'); return; }
    setBusy(true); setError('');
    const r = await window.agent.login(username, password);
    setBusy(false);
    if (r.ok) { setPassword(''); onLoggedIn(r.data); }
    else setError(r.error);
  };

  return (
    <Box sx={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg,#e6f6fb 0%,#f4f9fc 60%)' }}>
      <Paper elevation={0} sx={{ width: 420, p: 4, border: '1px solid #d6e8f0', borderRadius: 3, position: 'relative' }}>
        <Tooltip title="Settings">
          <IconButton size="small" onClick={onOpenSettings} sx={{ position: 'absolute', top: 12, right: 12 }}><Settings fontSize="small" /></IconButton>
        </Tooltip>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 0.5 }}>
          <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: 'primary.main', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Lock sx={{ color: '#fff' }} />
          </Box>
          <Box>
            <Typography variant="h6" sx={{ fontWeight: 700, lineHeight: 1.1 }}>QA Pariksha Agent</Typography>
            <Typography variant="caption" color="text.secondary">API testing · desktop</Typography>
          </Box>
        </Box>
        <Typography variant="body2" color="text.secondary" sx={{ mt: 2, mb: 2 }}>
          Sign in with your QA Pariksha account.
        </Typography>
        {notice && <Alert severity="info" sx={{ mb: 2 }}>{notice}</Alert>}
        <Box component="form" onSubmit={submit} sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <TextField label="Username" value={username} onChange={e => setUsername(e.target.value)} autoFocus fullWidth autoComplete="username" />
          <TextField label="Password" type="password" value={password} onChange={e => setPassword(e.target.value)} fullWidth autoComplete="current-password" />
          {error && <Alert severity="error">{error}</Alert>}
          <Button type="submit" variant="contained" size="large" disabled={busy}>
            {busy ? <CircularProgress size={22} sx={{ color: '#fff' }} /> : 'Sign in'}
          </Button>
        </Box>
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 3, wordBreak: 'break-all' }}>
          Server: {serverUrl} · v{version}
        </Typography>
      </Paper>
    </Box>
  );
};
