import React from 'react';
import { Box, Chip, TextField, Typography } from '@mui/material';

// Renders every level of the spec payload with real values:
//   field spec {value, required, validation} → label + chips + editor (recurses into object values)
//   container (plain object without "value")  → section header, recurse (HEADERS / BODY)
//   primitive                                 → editable text field (static header values)
export const isPlainObject = (v: any): v is Record<string, any> =>
  v !== null && typeof v === 'object' && !Array.isArray(v);
const isFieldSpec = (v: any) => isPlainObject(v) && Object.prototype.hasOwnProperty.call(v, 'value');

export const setIn = (obj: any, path: string[], value: any): any => {
  if (path.length === 0) return value;
  const [head, ...rest] = path;
  const base = isPlainObject(obj) ? obj : {};
  return { ...base, [head]: setIn(base[head], rest, value) };
};

// Keep the original JSON type when editing in a text box: 120 stays a number.
const coerceLikeOriginal = (original: any, input: string): any => {
  if (typeof original === 'number') {
    const n = Number(input);
    return input.trim() !== '' && Number.isFinite(n) ? n : input;
  }
  if (typeof original === 'boolean') {
    if (input.toLowerCase() === 'true') return true;
    if (input.toLowerCase() === 'false') return false;
  }
  return input;
};

const Primitive: React.FC<{ value: any; onChange: (v: any) => void }> = ({ value, onChange }) => (
  <TextField
    variant="standard" size="small" fullWidth
    value={value === null || value === undefined ? '' : String(value)}
    onChange={e => onChange(coerceLikeOriginal(value, e.target.value))}
    slotProps={{ htmlInput: { style: { fontSize: '0.8rem' } } }}
    sx={{ mt: 0.25 }}
  />
);

const showValues = (arr: any[]) => arr.map(x => (isPlainObject(x) || Array.isArray(x) ? JSON.stringify(x) : String(x))).join(' | ');

export const PayloadTree: React.FC<{
  node: Record<string, any>;
  path: string[];
  depth: number;
  onChange: (path: string[], value: any) => void;
}> = ({ node, path, depth, onChange }) => (
  <Box sx={depth > 0 ? { pl: 1.25, ml: 0.5, mt: 0.75, borderLeft: '2px solid #cdeefa' } : undefined}>
    {Object.entries(node || {}).map(([key, entry]) => {
      const p = [...path, key];
      if (isFieldSpec(entry)) {
        const val = entry.value;
        return (
          <Box key={key} sx={{ mb: 1.1 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75, flexWrap: 'wrap' }}>
              <Typography variant="caption" sx={{ fontWeight: 700 }}>{key}</Typography>
              {entry.required !== false
                ? <Chip label="required" size="small" sx={{ height: 16, fontSize: '0.6rem' }} />
                : <Chip label="optional" size="small" variant="outlined" sx={{ height: 16, fontSize: '0.6rem' }} />}
              {Array.isArray(val) && val.length > 1 && <Chip label={`${val.length} valid values`} size="small" color="info" sx={{ height: 16, fontSize: '0.6rem' }} />}
              {isPlainObject(val) && <Chip label={`${Object.keys(val).length} inner field(s)`} size="small" color="info" sx={{ height: 16, fontSize: '0.6rem' }} />}
            </Box>
            {isPlainObject(val)
              ? <PayloadTree node={val} path={[...p, 'value']} depth={depth + 1} onChange={onChange} />
              : Array.isArray(val)
                ? <Typography variant="caption" color="text.secondary" sx={{ display: 'block', wordBreak: 'break-all' }}>Values: {showValues(val)}</Typography>
                : <Primitive value={val} onChange={v => onChange([...p, 'value'], v)} />}
            {entry.validation && (
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>Rule: {entry.validation}</Typography>
            )}
          </Box>
        );
      }
      if (isPlainObject(entry)) {
        return (
          <Box key={key} sx={{ mb: 1.1 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
              <Typography variant="caption" sx={{ fontWeight: 700, color: '#0b7fa3' }}>{key}</Typography>
              <Chip label={`${Object.keys(entry).length} item(s)`} size="small" variant="outlined" sx={{ height: 16, fontSize: '0.6rem' }} />
            </Box>
            <PayloadTree node={entry} path={p} depth={depth + 1} onChange={onChange} />
          </Box>
        );
      }
      return (
        <Box key={key} sx={{ mb: 1.1 }}>
          <Typography variant="caption" sx={{ fontWeight: 700 }}>{key}</Typography>
          {Array.isArray(entry)
            ? <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>Values: {showValues(entry)}</Typography>
            : <Primitive value={entry} onChange={v => onChange(p, v)} />}
        </Box>
      );
    })}
  </Box>
);
