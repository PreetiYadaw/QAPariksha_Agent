import React, { useRef, useState } from 'react';
import {
  Alert, Box, Button, CircularProgress, Divider, FormControl, IconButton, InputLabel,
  MenuItem, Paper, Select, TextField, Tooltip, Typography,
} from '@mui/material';
import { Clear, CloudUploadOutlined, AutoAwesome, DataObject } from '@mui/icons-material';
import { PayloadTree, isPlainObject, setIn } from './PayloadTree';

export interface ApiSpec { api_name: string; api_url: string; method: string; payload: Record<string, any> }

export const API_TYPES = [
  { value: 'EIS', label: 'EIS' },
  { value: 'EIS_CHANNEL', label: 'EIS Channel' },
  { value: 'EIS_MICROSERVICES', label: 'EIS Microservices' },
];

export function parseSpec(text: string): ApiSpec {
  let raw: any;
  try { raw = JSON.parse(text); } catch (e: any) { throw new Error(`Not valid JSON — ${e.message}`); }
  if (!isPlainObject(raw)) throw new Error('The file must contain a JSON object.');
  if (!raw.api_url || typeof raw.api_url !== 'string') throw new Error('Missing "api_url".');
  if (!isPlainObject(raw.payload) || Object.keys(raw.payload).length === 0) throw new Error('"payload" must be a non-empty object.');
  return {
    api_name: String(raw.api_name || 'Unnamed API'),
    api_url: raw.api_url.trim(),
    method: String(raw.method || 'POST').toUpperCase(),
    payload: raw.payload,
  };
}

export const SpecPanel: React.FC<{
  spec: ApiSpec | null;
  fileName: string;
  onSpec: (s: ApiSpec | null, fileName: string) => void;
  apiType: string;
  onApiType: (t: string) => void;
  prompt: string;
  onPrompt: (p: string) => void;
  generating: boolean;
  onGenerate: () => void;
  locked: boolean;
}> = ({ spec, fileName, onSpec, apiType, onApiType, prompt, onPrompt, generating, onGenerate, locked }) => {
  const [error, setError] = useState('');
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const readFile = (f: File | undefined) => {
    setError('');
    if (!f) return;
    if (!f.name.toLowerCase().endsWith('.json')) { setError('Please choose a .json file.'); return; }
    const reader = new FileReader();
    reader.onerror = () => setError('Could not read the file.');
    reader.onload = () => {
      try { onSpec(parseSpec(String(reader.result || '')), f.name); }
      catch (e: any) { setError(e.message); }
    };
    reader.readAsText(f);
  };

  return (
    <Paper elevation={0} sx={{ border: '1px solid #d6e8f0', p: 2, display: 'flex', flexDirection: 'column', gap: 1.5, height: '100%', overflow: 'hidden' }}>
      <Typography variant="subtitle2" sx={{ fontWeight: 700, color: 'secondary.main' }}>1 · INPUT JSON</Typography>

      <input ref={inputRef} type="file" accept=".json,application/json" hidden
             onChange={e => { const f = e.target.files?.[0]; e.target.value = ''; readFile(f); }} />

      {!spec ? (
        <Box
          onClick={() => inputRef.current?.click()}
          onDragOver={e => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={e => { e.preventDefault(); setDragOver(false); readFile(e.dataTransfer.files?.[0]); }}
          sx={{
            border: '2px dashed', borderColor: dragOver ? 'primary.main' : '#b9dcea', borderRadius: 2,
            p: 3, textAlign: 'center', cursor: 'pointer', bgcolor: dragOver ? '#e6f6fb' : '#fafdff',
          }}>
          <CloudUploadOutlined sx={{ fontSize: 40, color: 'primary.main' }} />
          <Typography variant="body2" sx={{ fontWeight: 600, mt: 1 }}>Choose or drop the input JSON</Typography>
          <Typography variant="caption" color="text.secondary">{'{ api_name, api_url, method, payload }'}</Typography>
        </Box>
      ) : (
        <Box sx={{ border: '1px solid #cdeefa', borderRadius: 2, p: 1.25, bgcolor: '#f7fcfe' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <DataObject color="primary" fontSize="small" />
            <Typography variant="body2" sx={{ fontWeight: 700, flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{spec.api_name}</Typography>
            <Tooltip title="Choose another file"><span><IconButton size="small" disabled={locked} onClick={() => inputRef.current?.click()}><CloudUploadOutlined fontSize="small" /></IconButton></span></Tooltip>
            <Tooltip title="Clear"><span><IconButton size="small" disabled={locked} onClick={() => { setError(''); onSpec(null, ''); }} sx={{ color: 'error.main' }}><Clear fontSize="small" /></IconButton></span></Tooltip>
          </Box>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', wordBreak: 'break-all' }}>{spec.method} · {spec.api_url}</Typography>
          <Typography variant="caption" color="text.secondary">{fileName} · {Object.keys(spec.payload).length} top-level field(s)</Typography>
        </Box>
      )}
      {error && <Alert severity="error" onClose={() => setError('')}>{error}</Alert>}

      {spec && (
        <Box sx={{ flex: 1, minHeight: 120, overflowY: 'auto', pr: 0.5 }}>
          <PayloadTree node={spec.payload} path={[]} depth={0}
                       onChange={(p, v) => onSpec({ ...spec, payload: setIn(spec.payload, p, v) }, fileName)} />
        </Box>
      )}

      <Divider />
      <FormControl size="small" fullWidth>
        <InputLabel>API type</InputLabel>
        <Select label="API type" value={apiType} onChange={e => onApiType(e.target.value)} disabled={locked}>
          {API_TYPES.map(t => <MenuItem key={t.value} value={t.value}>{t.label}</MenuItem>)}
        </Select>
      </FormControl>
      <TextField size="small" label="Additional instructions (optional)" multiline minRows={2} maxRows={4}
                 value={prompt} onChange={e => onPrompt(e.target.value)} disabled={locked} />
      <Button variant="contained" size="large" startIcon={generating ? <CircularProgress size={18} sx={{ color: '#fff' }} /> : <AutoAwesome />}
              disabled={!spec || generating || locked} onClick={onGenerate}>
        {generating ? 'Generating test cases…' : 'Generate test cases'}
      </Button>
    </Paper>
  );
};
