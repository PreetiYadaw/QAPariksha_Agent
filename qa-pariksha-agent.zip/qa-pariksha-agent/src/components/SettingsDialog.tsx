import React, { useEffect, useState } from 'react';
import {
  Alert, Box, Button, Dialog, DialogActions, DialogContent, DialogTitle,
  FormControlLabel, Switch, TextField, Typography, CircularProgress,
} from '@mui/material';
import type { AgentConfig, ClientConfig } from '../agent.d';

export const SettingsDialog: React.FC<{
  open: boolean;
  config: AgentConfig | null;
  onClose: () => void;
  onSaved: (c: AgentConfig, serverChanged: boolean) => void;
}> = ({ open, config, onClose, onSaved }) => {
  const [form, setForm] = useState<AgentConfig | null>(config);
  const [error, setError] = useState('');
  const [check, setCheck] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => { if (open) { setForm(config); setError(''); setCheck(null); } }, [open, config]);
  if (!form) return null;

  const set = (k: keyof AgentConfig, v: any) => setForm({ ...form, [k]: v });

  const save = async (): Promise<AgentConfig | null> => {
    setError('');
    const r = await window.agent.saveConfig({
      serverUrl: form.serverUrl, eisConcurrency: form.eisConcurrency,
      eisTimeoutSec: form.eisTimeoutSec, eisAllowUntrustedCert: form.eisAllowUntrustedCert,
    });
    if (!r.ok) { setError(r.error); return null; }
    return r.data;
  };

  const testConnection = async () => {
    setBusy(true); setCheck(null);
    const saved = await save();
    if (saved) {
      const r = await window.agent.checkServer();
      setCheck(r.ok
        ? { ok: true, text: `Connected. Allowed EIS host(s): ${(r.data as ClientConfig).eis_allowed_hosts.join(', ')}` }
        : { ok: false, text: r.error });
    }
    setBusy(false);
  };

  const saveAndClose = async () => {
    const saved = await save();
    if (saved) onSaved(saved, saved.serverUrl !== config?.serverUrl);
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>Settings</DialogTitle>
      <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: '12px !important' }}>
        <Box>
          <TextField label="QA Pariksha server URL" fullWidth value={form.serverUrl}
                     onChange={e => set('serverUrl', e.target.value)}
                     helperText="Backend address, e.g. https://qapariksha-api.example.sbi:1000 — changing it logs you out." />
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mt: 1 }}>
            <Button size="small" variant="outlined" onClick={testConnection} disabled={busy}>
              {busy ? <CircularProgress size={16} /> : 'Test connection'}
            </Button>
            {check && <Typography variant="body2" color={check.ok ? 'success.main' : 'error.main'}>{check.text}</Typography>}
          </Box>
        </Box>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <TextField label="Parallel EIS calls" type="number" value={form.eisConcurrency}
                     onChange={e => set('eisConcurrency', e.target.value)} helperText="1–32 (default 8)" fullWidth />
          <TextField label="EIS timeout (seconds)" type="number" value={form.eisTimeoutSec}
                     onChange={e => set('eisTimeoutSec', e.target.value)} helperText="5–300 (default 60)" fullWidth />
        </Box>
        <Box>
          <FormControlLabel
            control={<Switch checked={form.eisAllowUntrustedCert} onChange={e => set('eisAllowUntrustedCert', e.target.checked)} />}
            label="Accept untrusted certificate from allowed EIS hosts" />
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
            Only if the EIS UAT certificate isn't trusted on this PC. Better: install the bank's root CA in Windows.
            Applies only to EIS hosts allowed by the QA Pariksha server.
          </Typography>
        </Box>
        {error && <Alert severity="error">{error}</Alert>}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={saveAndClose}>Save</Button>
      </DialogActions>
    </Dialog>
  );
};
