import { createTheme } from '@mui/material';

export const BRAND = '#1aa7d1';
export const theme = createTheme({
  palette: {
    primary: { main: BRAND, contrastText: '#fff' },
    secondary: { main: '#1E2761' },
    background: { default: '#f4f9fc' },
  },
  shape: { borderRadius: 8 },
  typography: { fontFamily: '"Segoe UI", Calibri, Arial, sans-serif', button: { textTransform: 'none', fontWeight: 600 } },
  components: {
    MuiButton: { defaultProps: { disableElevation: true } },
    MuiPaper: { styleOverrides: { root: { backgroundImage: 'none' } } },
  },
});
