import React, { useCallback, useEffect, useState } from 'react';
import { Alert, AppBar, Box, Chip, CircularProgress, IconButton, Toolbar, Tooltip, Typography } from '@mui/material';
import { Logout, Settings } from '@mui/icons-material';
import type { AgentConfig, EvaluateResult, GenerateResult, RunProgress, Testcase, User } from './agent.d';
import { LoginView } from './components/LoginView';
import { SettingsDialog } from './components/SettingsDialog';
import { SpecPanel, type ApiSpec } from './components/SpecPanel';
import { ResultsPanel } from './components/ResultsPanel';
import { API_TC_COLUMNS, buildEditableWorkbook, buildReportWorkbook, parseEditedWorkbook } from './excel';

const newer = (a: string, b: string) => { // is a > b (semver-ish)
  const pa = a.split('.').map(Number), pb = b.split('.').map(Number);
  for (let i = 0; i < 3; i++) { if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0); }
  return false;
};
const safeName = (s: string) => (s || 'api').replace(/[^A-Za-z0-9_-]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 60) || 'api';

export default function App() {
  const [booting, setBooting] = useState(true);
  const [config, setConfig] = useState<AgentConfig | null>(null);
  const [version, setVersion] = useState('');
  const [user, setUser] = useState<User | null>(null);
  const [notice, setNotice] = useState('');
  const [banner, setBanner] = useState('');
  const [settingsOpen, setSettingsOpen] = useState(false);

  // workflow state
  const [spec, setSpec] = useState<ApiSpec | null>(null);
  const [fileName, setFileName] = useState('');
  const [apiType, setApiType] = useState('EIS_CHANNEL');
  const [prompt, setPrompt] = useState('');
  const [result, setResult] = useState<GenerateResult | null>(null);
  const [uploaded, setUploaded] = useState<Testcase[] | null>(null);
  const [ran, setRan] = useState<Testcase[] | null>(null);
  const [evaluated, setEvaluated] = useState<EvaluateResult | null>(null);
  const [generating, setGenerating] = useState(false);
  const [running, setRunning] = useState(false);
  const [evaluating, setEvaluating] = useState(false);
  const [progress, setProgress] = useState<RunProgress | null>(null);
  const [error, setError] = useState('');

  const resetWork = () => { setResult(null); setUploaded(null); setRan(null); setEvaluated(null); setError(''); };

  const checkVersion = useCallback(async (v: string) => {
    const r = await window.agent.checkServer();
    if (r.ok && newer(r.data.min_agent_version, v))
      setBanner(`This agent (v${v}) is older than the minimum supported version (v${r.data.min_agent_version}). Please install the latest version.`);
  }, []);

  useEffect(() => {
    (async () => {
      const info = await window.agent.appInfo();
      if (info.ok) { setConfig(info.data.config); setVersion(info.data.version); }
      const s = await window.agent.restoreSession();
      if (s.ok && s.data) setUser(s.data);
      if (info.ok) checkVersion(info.data.version);
      setBooting(false);
    })();
    return window.agent.onSessionExpired(() => {
      setUser(null);
      setNotice('Your session expired. Please sign in again — your work on screen is kept.');
    });
  }, [checkVersion]);

  const logout = async () => {
    await window.agent.logout();
    setUser(null); setNotice(''); resetWork(); setSpec(null); setFileName('');
  };

  // ── Workflow ──────────────────────────────────────────────────────────────
  const sourceRows = uploaded ?? result?.combined_testcases ?? [];
  const rows = evaluated?.testcases ?? ran ?? sourceRows;

  const generate = async () => {
    if (!spec) return;
    setGenerating(true); resetWork();
    const r = await window.agent.generate(spec, apiType, prompt.trim() || null);
    setGenerating(false);
    // the server returns the API name as document_name
    if (r.ok) setResult({ ...r.data, api_name: r.data.api_name || r.data.document_name || spec.api_name });
    else setError(r.error);
  };

  const run = async () => {
    if (!result) return;
    setRunning(true); setError(''); setEvaluated(null); setProgress({ done: 0, total: sourceRows.length, phase: 'Starting' });
    const off = window.agent.onRunProgress(setProgress);
    const r = await window.agent.run(sourceRows, result.api_url, result.generated_reference_number ?? null);
    off(); setRunning(false); setProgress(null);
    if (r.ok) setRan(r.data); else setError(r.error);
  };

  const evaluate = async () => {
    if (!ran) return;
    setEvaluating(true); setError('');
    const r = await window.agent.evaluate(ran);
    setEvaluating(false);
    if (r.ok) setEvaluated(r.data); else setError(r.error);
  };

  const save = async (name: string, base64: string) => {
    const r = await window.agent.saveFile(name, base64, 'xlsx');
    if (!r.ok) setError(r.error);
  };

  const downloadEditable = () => {
    if (!result) return;
    save(`${safeName(result.api_name)}_api_testcases_editable.xlsx`, buildEditableWorkbook(sourceRows, result.api_url, result.method));
  };

  const uploadEdited = (f: File) => {
    const reader = new FileReader();
    reader.onerror = () => setError('Could not read the uploaded file.');
    reader.onload = () => {
      try {
        setUploaded(parseEditedWorkbook(reader.result as ArrayBuffer));
        setRan(null); setEvaluated(null); setError('');
      } catch (e: any) { setError(e.message); }
    };
    reader.readAsArrayBuffer(f);
  };

  const downloadReport = () => {
    if (!result) return;
    const cols = API_TC_COLUMNS.filter(c => (c === 'Pass_Fail' || c === 'Remarks') ? !!evaluated : true);
    const suffix = evaluated ? '_evaluated' : '_with_response';
    save(`${safeName(result.api_name)}_api_testcases${suffix}.xlsx`, buildReportWorkbook(rows, cols, result.api_url, result.method));
  };

  // ── Render ────────────────────────────────────────────────────────────────
  if (booting) {
    return <Box sx={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><CircularProgress /></Box>;
  }

  const settings = (
    <SettingsDialog open={settingsOpen} config={config} onClose={() => setSettingsOpen(false)}
      onSaved={(c, serverChanged) => {
        setConfig(c); setSettingsOpen(false);
        if (serverChanged) { setUser(null); resetWork(); setNotice('Server changed — please sign in.'); checkVersion(version); }
      }} />
  );

  if (!user) {
    return <>
      <LoginView serverUrl={config?.serverUrl || ''} version={version} notice={notice}
                 onLoggedIn={u => { setUser(u); setNotice(''); }} onOpenSettings={() => setSettingsOpen(true)} />
      {settings}
    </>;
  }

  const busy = generating || running || evaluating;

  return (
    <Box sx={{ height: '100vh', display: 'flex', flexDirection: 'column' }}>
      <AppBar position="static" elevation={0} sx={{ bgcolor: '#1E2761' }}>
        <Toolbar variant="dense" sx={{ gap: 1.5 }}>
          <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>QA Pariksha Agent</Typography>
          <Typography variant="caption" sx={{ opacity: 0.75 }}>API testing</Typography>
          <Box sx={{ flex: 1 }} />
          <Chip size="small" label={user.testcase_client || 'UAT'} sx={{ bgcolor: '#1aa7d1', color: '#fff', fontWeight: 700 }} />
          <Typography variant="body2">{[user.first_name, user.last_name].filter(Boolean).join(' ') || user.username}</Typography>
          <Tooltip title="Settings"><span><IconButton size="small" sx={{ color: '#fff' }} onClick={() => setSettingsOpen(true)} disabled={busy}><Settings fontSize="small" /></IconButton></span></Tooltip>
          <Tooltip title="Sign out"><span><IconButton size="small" sx={{ color: '#fff' }} onClick={logout} disabled={busy}><Logout fontSize="small" /></IconButton></span></Tooltip>
        </Toolbar>
      </AppBar>
      {banner && <Alert severity="warning" onClose={() => setBanner('')} sx={{ borderRadius: 0 }}>{banner}</Alert>}
      {user.must_change_password && <Alert severity="info" sx={{ borderRadius: 0 }}>Your account needs a password change — please change it in the QA Pariksha web app.</Alert>}

      <Box sx={{ flex: 1, display: 'flex', gap: 2, p: 2, minHeight: 0 }}>
        <Box sx={{ width: 380, flexShrink: 0, minHeight: 0 }}>
          <SpecPanel spec={spec} fileName={fileName}
                     onSpec={(s, n) => { setSpec(s); setFileName(n); if (!s) resetWork(); }}
                     apiType={apiType} onApiType={setApiType} prompt={prompt} onPrompt={setPrompt}
                     generating={generating} onGenerate={generate} locked={running || evaluating} />
        </Box>
        <Box sx={{ flex: 1, minWidth: 0, minHeight: 0 }}>
          {error && !result && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}
          <ResultsPanel
            result={result} rows={rows}
            hasRun={!!ran} hasEvaluated={!!evaluated} usingUploaded={!!uploaded}
            evalSummary={evaluated ? evaluated.summary : null}
            running={running} evaluating={evaluating} progress={progress}
            error={result ? error : ''} onClearError={() => setError('')}
            onRun={run} onCancel={() => window.agent.cancelRun()} onEvaluate={evaluate}
            onDownloadEditable={downloadEditable} onUploadEdited={uploadEdited}
            onDiscardUpload={() => { setUploaded(null); setRan(null); setEvaluated(null); }}
            onDownloadReport={downloadReport} />
        </Box>
      </Box>
      {settings}
    </Box>
  );
}
