// Types for the API exposed by electron/preload.js
export type Result<T> = { ok: true; data: T } | { ok: false; error: string; status?: number };

export interface AgentConfig {
  serverUrl: string; apiPrefix: string;
  eisConcurrency: number; eisTimeoutSec: number; eisAllowUntrustedCert: boolean;
}
export interface AppInfo { version: string; config: AgentConfig; encryptionAvailable: boolean }
export interface ClientConfig { min_agent_version: string; eis_allowed_hosts: string[]; max_batch: number; token_expire_minutes: number }
export interface User {
  username: string; first_name: string; last_name: string; email: string;
  role: string; testcase_client: string; must_change_password: boolean;
}
export type Testcase = Record<string, any>;
export interface GenerateResult {
  api_name: string; document_name?: string; api_url: string; method: string; api_type: string;
  generated_reference_number?: string | null;
  combined_testcases: Testcase[];
  summary: { total_testcase_count: number; positive_count: number; negative_count: number };
}
export interface EvaluateResult { testcases: Testcase[]; summary: { total_testcase_count: number; pass_count: number; fail_count: number } }
export interface RunProgress { done: number; total: number; phase: string }

declare global {
  interface Window {
    agent: {
      appInfo(): Promise<Result<AppInfo>>;
      saveConfig(patch: Partial<AgentConfig>): Promise<Result<AgentConfig>>;
      checkServer(): Promise<Result<ClientConfig>>;
      login(username: string, password: string): Promise<Result<User>>;
      restoreSession(): Promise<Result<User | null>>;
      logout(): Promise<Result<boolean>>;
      generate(apiSpec: any, apiType: string, userPrompt: string | null): Promise<Result<GenerateResult>>;
      run(testcases: Testcase[], apiUrl: string, generatedRrn: string | null): Promise<Result<Testcase[]>>;
      cancelRun(): Promise<Result<boolean>>;
      evaluate(testcases: Testcase[]): Promise<Result<EvaluateResult>>;
      saveFile(defaultName: string, base64: string, kind: 'xlsx' | 'json'): Promise<Result<string | null>>;
      revealFile(path: string): Promise<Result<boolean>>;
      onRunProgress(cb: (p: RunProgress) => void): () => void;
      onSessionExpired(cb: () => void): () => void;
    };
  }
}
