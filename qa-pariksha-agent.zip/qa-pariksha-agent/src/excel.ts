// src/excel.ts — same workbook format as the QA Pariksha web app, so an .xlsx
// edited in one can be re-uploaded in the other.
import * as XLSX from 'xlsx';
import type { Testcase } from './agent.d';

export const API_TC_COLUMNS = [
  'Function Description', 'Test Case ID', 'Test Case Description',
  'Test Case Type', 'API_URL', 'API_METHOD', 'Test Data',
  'Encrypted_Payload', 'Encrypted_Response', 'Actual_Response',
  'Pass_Fail', 'Remarks',
];
export const EDITABLE_API_TC_COLUMNS = API_TC_COLUMNS.slice(0, 7);

const EXCEL_CELL_LIMIT = 32000; // Excel's hard limit is 32,767 characters per cell

export const asText = (v: any, pretty = true): string => {
  if (v === undefined || v === null) return '';
  if (typeof v === 'object') return JSON.stringify(v, null, pretty ? 2 : 0);
  return String(v);
};

const cell = (v: any, pretty = true) => {
  const s = asText(v, pretty);
  return s.length > EXCEL_CELL_LIMIT ? s.slice(0, EXCEL_CELL_LIMIT) + ' …[truncated: Excel cell limit]' : s;
};

const colWidths = (rows: Record<string, any>[], cols: string[]) =>
  cols.map(h => ({ wch: Math.min(Math.max(h.length, ...rows.map(r => String(r[h] ?? '').length)) + 2, 100) }));

const toBase64 = (wb: XLSX.WorkBook) => XLSX.write(wb, { type: 'base64', bookType: 'xlsx' }) as string;

export function buildEditableWorkbook(testcases: Testcase[], apiUrl: string, method: string): string {
  const rows = testcases.map(tc => {
    const row: Record<string, any> = {};
    EDITABLE_API_TC_COLUMNS.forEach(c => {
      if (c === 'Test Data') row[c] = cell(tc['Test Data']);
      else if (c === 'API_URL') row[c] = tc['API_URL'] || apiUrl || '';
      else if (c === 'API_METHOD') row[c] = tc['API_METHOD'] || method || '';
      else row[c] = tc[c] ?? '';
    });
    return row;
  });
  const ws = XLSX.utils.json_to_sheet(rows, { header: EDITABLE_API_TC_COLUMNS });
  ws['!cols'] = colWidths(rows, EDITABLE_API_TC_COLUMNS);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'API Test Cases');
  const readMe = [
    'One row per test case. Edit values below, save, then re-upload this file with "Upload edited" in the app.',
    "1. Don't rename, remove, or reorder columns — the app matches them by header name.",
    '2. "Test Data" must stay valid JSON after your edit (matching quotes/braces) — it is re-parsed on upload.',
    '3. If you change a value inside "Test Data" (the payload), also update "Test Case Description" for that row.',
    '4. Leave "Test Case ID" unchanged unless you mean to — it is used to match results back to each row.',
  ].map(t => ({ 'Read this before editing': t }));
  const wsInfo = XLSX.utils.json_to_sheet(readMe);
  wsInfo['!cols'] = [{ wch: 110 }];
  XLSX.utils.book_append_sheet(wb, wsInfo, 'Read Me First');
  return toBase64(wb);
}

export function buildReportWorkbook(testcases: Testcase[], columns: string[], apiUrl: string, method: string): string {
  const rows = testcases.map(tc => {
    const row: Record<string, any> = {};
    columns.forEach(c => {
      if (c === 'API_URL') row[c] = tc['API_URL'] || apiUrl || '';
      else if (c === 'API_METHOD') row[c] = tc['API_METHOD'] || method || '';
      else row[c] = cell(tc[c], c !== 'Encrypted_Payload' && c !== 'Encrypted_Response');
    });
    return row;
  });
  const ws = XLSX.utils.json_to_sheet(rows, { header: columns });
  ws['!cols'] = colWidths(rows, columns);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'API Test Cases');
  return toBase64(wb);
}

/** Parses an edited workbook. Throws a readable Error on any problem. */
export function parseEditedWorkbook(data: ArrayBuffer): Testcase[] {
  const wb = XLSX.read(data, { type: 'array' });
  const sheetName = wb.SheetNames.find(n => n !== 'Read Me First') || wb.SheetNames[0];
  const rows: any[] = XLSX.utils.sheet_to_json(wb.Sheets[sheetName], { defval: '' });
  if (rows.length === 0) throw new Error('The uploaded file has no test case rows.');
  const missing = ['Test Case ID', 'Test Data'].filter(c => !(c in rows[0]));
  if (missing.length) throw new Error(`Missing column(s): ${missing.join(', ')}. Use the file downloaded from this app.`);
  const seen = new Set<string>();
  return rows.map((r, idx) => {
    const id = String(r['Test Case ID'] || '').trim();
    if (!id) throw new Error(`Row ${idx + 2}: "Test Case ID" is empty.`);
    if (seen.has(id)) throw new Error(`Row ${idx + 2}: duplicate Test Case ID "${id}" — IDs must be unique (results are matched by ID).`);
    seen.add(id);
    let testData: any = r['Test Data'];
    if (typeof testData === 'string' && testData.trim()) {
      try { testData = JSON.parse(testData); }
      catch { throw new Error(`Row ${idx + 2} (Test Case ID: ${id}) — "Test Data" is not valid JSON. Fix it and re-upload.`); }
    }
    return { ...r, 'Test Case ID': id, 'Test Data': testData };
  });
}
