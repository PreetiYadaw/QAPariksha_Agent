// electron/main.js — QA Pariksha Agent (main process)
const { app, BrowserWindow, ipcMain, dialog, session, safeStorage, shell, Menu } = require("electron");
const fs = require("fs");
const path = require("path");
const { createConfigStore } = require("./lib/config");
const { createTokenStore, jwtExpiryMs } = require("./lib/tokenStore");
const { createQaClient, ApiError } = require("./lib/qaClient");
const { runTestcases } = require("./lib/runPipeline");

const DEV_URL = process.env.VITE_DEV_SERVER_URL || "";
const APP_VERSION = require("../package.json").version; // app.getVersion() is Electron's own version when not launched via "electron ."
let win = null;
let config, tokens, client, apiSession, eisSession;
let allowedEisHosts = new Set();
let refreshTimer = null;
let runAbort = null;

if (!app.requestSingleInstanceLock()) app.quit();
app.on("second-instance", () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });

// ── Network sessions ─────────────────────────────────────────────────────────
// Separate, in-memory sessions for (a) QA Pariksha API calls and (b) EIS calls.
// Both use Chromium's network stack → Windows certificate store + system proxy.
function setupSessions() {
  apiSession = session.fromPartition("qa-agent-api", { cache: false });
  eisSession = session.fromPartition("qa-agent-eis", { cache: false });

  // Auth is Bearer-only: drop any Set-Cookie so no cookie session can form
  // (the server prefers cookies over Bearer if both are present).
  for (const s of [apiSession, eisSession]) {
    s.webRequest.onHeadersReceived((details, cb) => {
      const h = { ...details.responseHeaders };
      for (const k of Object.keys(h)) if (k.toLowerCase() === "set-cookie") delete h[k];
      cb({ responseHeaders: h });
    });
  }

  // Optional, opt-in: accept a non-trusted certificate ONLY for allowed EIS hosts
  // (the server-side run uses verify=False; prefer installing the bank CA instead).
  eisSession.setCertificateVerifyProc((req, cb) => {
    const ok = config.load().eisAllowUntrustedCert && allowedEisHosts.has(String(req.hostname).toLowerCase());
    cb(ok ? 0 : -3); // 0 = trust, -3 = use Chromium's normal verification result
  });
}

// ── Token refresh (server tokens expire after ~30 min) ───────────────────────
function scheduleRefresh() {
  clearTimeout(refreshTimer);
  const t = tokens.get();
  const exp = t && jwtExpiryMs(t);
  if (!exp) return;
  const inMs = Math.max(30_000, (exp - Date.now()) * 0.8);
  refreshTimer = setTimeout(async () => {
    try {
      const r = await client.refresh();
      tokens.set(r.access_token);
      scheduleRefresh();
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) sessionExpired();
    }
  }, inMs);
}

function sessionExpired() {
  clearTimeout(refreshTimer);
  tokens.clear();
  if (win) win.webContents.send("auth:expired");
}

// ── IPC (every handler checks the call comes from our own page) ──────────────
function trusted(event) {
  const url = event.senderFrame ? event.senderFrame.url : "";
  return (DEV_URL && url.startsWith(DEV_URL)) || url.startsWith("file://");
}

function handle(channel, fn) {
  ipcMain.handle(channel, async (event, ...args) => {
    if (!trusted(event)) throw new Error("Blocked: untrusted sender");
    try {
      return { ok: true, data: await fn(...args) };
    } catch (e) {
      if (e instanceof ApiError && e.status === 401 && channel !== "auth:login") sessionExpired();
      return { ok: false, error: e && e.message ? e.message : String(e), status: e && e.status };
    }
  });
}

async function refreshAllowedHosts() {
  try {
    const cc = await client.clientConfig();
    allowedEisHosts = new Set((cc.eis_allowed_hosts || []).map(h => h.toLowerCase()));
    return cc;
  } catch {
    return null;
  }
}

function registerIpc() {
  handle("app:info", async () => ({
    version: APP_VERSION,
    config: config.load(),
    encryptionAvailable: safeStorage.isEncryptionAvailable(),
  }));
  handle("config:save", async (patch) => {
    const before = config.load().serverUrl;
    const next = config.save(patch || {});
    if (next.serverUrl !== before) { tokens.clear(); clearTimeout(refreshTimer); }
    return next;
  });
  handle("server:check", async () => {
    const cc = await client.clientConfig();
    allowedEisHosts = new Set((cc.eis_allowed_hosts || []).map(h => h.toLowerCase()));
    return cc;
  });

  handle("auth:login", async (username, password) => {
    const r = await client.login(String(username || "").trim(), String(password || ""));
    tokens.set(r.access_token);
    const user = await client.me();
    scheduleRefresh();
    await refreshAllowedHosts();
    return user;
  });
  handle("auth:restore", async () => {
    if (!tokens.get()) return null;
    try {
      const user = await client.me();
      scheduleRefresh();
      await refreshAllowedHosts();
      return user;
    } catch {
      tokens.clear();
      return null;
    }
  });
  handle("auth:logout", async () => {
    try { if (tokens.get()) await client.logout(); } catch { /* best effort */ }
    clearTimeout(refreshTimer);
    tokens.clear();
    return true;
  });

  handle("tc:generate", async (apiSpec, apiType, userPrompt) => client.generate(apiSpec, apiType, userPrompt));

  handle("tc:run", async (testcases, apiUrl, generatedRrn) => {
    if (!Array.isArray(testcases) || testcases.length === 0) throw new Error("No test cases to run.");
    if (allowedEisHosts.size === 0) await refreshAllowedHosts();
    const c = config.load();
    runAbort = new AbortController();
    try {
      return await runTestcases({
        client,
        eisFetch: (url, init) => eisSession.fetch(url, init),
        testcases, apiUrl, generatedRrn,
        concurrency: c.eisConcurrency,
        timeoutMs: c.eisTimeoutSec * 1000,
        signal: runAbort.signal,
        onProgress: (done, total, phase) => win && win.webContents.send("tc:run-progress", { done, total, phase }),
      });
    } finally {
      runAbort = null;
    }
  });
  handle("tc:cancel-run", async () => { if (runAbort) runAbort.abort(); return true; });

  handle("tc:evaluate", async (testcases) => client.evaluate(testcases));

  handle("file:save", async (defaultName, base64, kind) => {
    const filters = kind === "json" ? [{ name: "JSON", extensions: ["json"] }] : [{ name: "Excel workbook", extensions: ["xlsx"] }];
    const { canceled, filePath } = await dialog.showSaveDialog(win, { defaultPath: defaultName, filters });
    if (canceled || !filePath) return null;
    fs.writeFileSync(filePath, Buffer.from(base64, "base64"));
    return filePath;
  });
  handle("file:reveal", async (p) => { if (p && fs.existsSync(p)) shell.showItemInFolder(p); return true; });
}

// ── Window ───────────────────────────────────────────────────────────────────
function createWindow() {
  win = new BrowserWindow({
    width: 1480,
    height: 920,
    minWidth: 1100,
    minHeight: 700,
    title: "QA Pariksha Agent",
    backgroundColor: "#f4f9fc",
    show: false,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      spellcheck: false,
    },
  });
  win.once("ready-to-show", () => win.show());

  // Never navigate away or open new windows from the app page.
  win.webContents.on("will-navigate", (e, url) => {
    if (!(DEV_URL && url.startsWith(DEV_URL))) e.preventDefault();
  });
  win.webContents.setWindowOpenHandler(() => ({ action: "deny" }));

  if (DEV_URL) {
    win.loadURL(DEV_URL);
    win.webContents.openDevTools({ mode: "detach" });
  } else {
    win.loadFile(path.join(__dirname, "..", "dist", "index.html"));
  }
  win.on("closed", () => { win = null; });
}

app.whenReady().then(() => {
  const dir = app.getPath("userData");
  config = createConfigStore(dir);
  tokens = createTokenStore(dir, safeStorage);
  setupSessions();
  client = createQaClient({
    fetchImpl: (url, init) => apiSession.fetch(url, init),
    getConfig: () => config.load(),
    getToken: () => tokens.get(),
  });
  registerIpc();
  if (!DEV_URL) Menu.setApplicationMenu(null);
  createWindow();
});

app.on("window-all-closed", () => app.quit());
