// electron/preload.js — exposes a small, explicit API to the React UI.
// No Node, no ipcRenderer, no token ever reaches the page.
const { contextBridge, ipcRenderer } = require("electron");

const call = (channel, ...args) => ipcRenderer.invoke(channel, ...args);

contextBridge.exposeInMainWorld("agent", {
  appInfo: () => call("app:info"),
  saveConfig: (patch) => call("config:save", patch),
  checkServer: () => call("server:check"),

  login: (username, password) => call("auth:login", username, password),
  restoreSession: () => call("auth:restore"),
  logout: () => call("auth:logout"),

  generate: (apiSpec, apiType, userPrompt) => call("tc:generate", apiSpec, apiType, userPrompt),
  run: (testcases, apiUrl, generatedRrn) => call("tc:run", testcases, apiUrl, generatedRrn),
  cancelRun: () => call("tc:cancel-run"),
  evaluate: (testcases) => call("tc:evaluate", testcases),

  saveFile: (defaultName, base64, kind) => call("file:save", defaultName, base64, kind),
  revealFile: (p) => call("file:reveal", p),

  onRunProgress: (cb) => {
    const h = (_e, p) => cb(p);
    ipcRenderer.on("tc:run-progress", h);
    return () => ipcRenderer.removeListener("tc:run-progress", h);
  },
  onSessionExpired: (cb) => {
    const h = () => cb();
    ipcRenderer.on("auth:expired", h);
    return () => ipcRenderer.removeListener("auth:expired", h);
  },
});
