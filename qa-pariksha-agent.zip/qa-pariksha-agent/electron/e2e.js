// electron/e2e.js — end-to-end UI test (NOT shipped; excluded in package.json "files").
//   E2E_SERVER=http://127.0.0.1:8765 E2E_USER=tester E2E_PASS=... E2E_SPEC=spec.json electron electron/e2e.js
const { app, BrowserWindow } = require("electron");
const fs = require("fs");
const path = require("path");
const OUT = process.env.E2E_OUT || "/tmp/agent-e2e";
const tmp = path.join(OUT, "userdata");
fs.rmSync(OUT, { recursive: true, force: true });
fs.mkdirSync(tmp, { recursive: true });
fs.writeFileSync(path.join(tmp, "config.json"), JSON.stringify({ serverUrl: process.env.E2E_SERVER }));
app.setPath("userData", tmp);
require("./main.js");

const sleep = (ms) => new Promise(r => setTimeout(r, ms));
app.whenReady().then(async () => {
  let win;
  while (!(win = BrowserWindow.getAllWindows()[0])) await sleep(100);
  await new Promise(r => win.webContents.once("did-finish-load", r));
  const js = (code) => win.webContents.executeJavaScript(code);
  const shot = async (name) => fs.writeFileSync(path.join(OUT, name), (await win.webContents.capturePage()).toPNG());
  const waitText = async (t, ms = 60000) => {
    const end = Date.now() + ms;
    while (Date.now() < end) { if (await js(`document.body.innerText.includes(${JSON.stringify(t)})`)) return; await sleep(250); }
    throw new Error(`timeout waiting for "${t}"`);
  };
  const click = (t) => js(`(() => { const b=[...document.querySelectorAll('button')].find(b=>b.textContent.trim().startsWith(${JSON.stringify(t)}) && !b.disabled); if(!b) throw new Error('no button ${t}'); b.click(); })()`);
  const setVal = (sel, v) => js(`(() => { const el=document.querySelector(${JSON.stringify(sel)}); const s=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set; s.call(el, ${JSON.stringify(v)}); el.dispatchEvent(new Event('input',{bubbles:true})); })()`);
  try {
    win.setSize(1480, 920);
    await waitText("Sign in with your QA Pariksha account");
    await shot("1_login.png");
    // wrong password first → server error message shown
    await setVal('input[autocomplete="username"]', process.env.E2E_USER);
    await setVal('input[autocomplete="current-password"]', "wrong");
    await click("Sign in");
    await waitText("Incorrect username or password");
    await setVal('input[autocomplete="current-password"]', process.env.E2E_PASS);
    await click("Sign in");
    await waitText("Choose or drop the input JSON");
    const spec = fs.readFileSync(process.env.E2E_SPEC, "utf-8");
    await js(`(() => { const i=document.querySelector('input[type=file][accept*="json"]'); const dt=new DataTransfer();
      dt.items.add(new File([${JSON.stringify(spec)}], 'payment_spec.json', {type:'application/json'})); i.files=dt.files;
      i.dispatchEvent(new Event('change',{bubbles:true})); })()`);
    await waitText("inner field(s)");
    await shot("2_spec_loaded.png");
    await click("Generate test cases");
    await waitText("Run all on EIS");
    await shot("3_generated.png");
    await click("Run all on EIS");
    await waitText("Evaluate pass / fail", 120000);
    await shot("4_ran.png");
    await click("Evaluate pass / fail");
    await waitText("Pass ", 120000);
    await sleep(500);
    await shot("5_evaluated.png");
    // open a row's details
    await js(`document.querySelectorAll('tbody tr')[0].click()`);
    await waitText("Encrypted Payload");
    await sleep(300);
    await shot("6_detail.png");
    const summary = await js(`[...document.querySelectorAll('.MuiChip-label')].map(c=>c.textContent).join(' | ')`);
    console.log("E2E OK —", summary);
  } catch (e) {
    console.error("E2E FAILED:", e.message);
    await shot("error.png");
    process.exitCode = 1;
  }
  app.quit();
});
