# QA Pariksha Agent (Electron desktop app)

Desktop app for QA Pariksha API testing. The flow is the same as the web app:
**Upload input JSON → Generate → (optional Excel edit) → Run on EIS → Evaluate Pass/Fail → Download report**

| Step | Who does it |
|---|---|
| Login, session refresh, logout | QA Pariksha server (`/login`, `/agent/auth/refresh`, `/logout`) |
| Generate test cases | QA Pariksha server (`/generate-api-testcases`) — unchanged |
| **Run on EIS** | **This app sends the HTTP call to EIS from the tester's PC.** The server only encrypts/signs (`/agent/eis/prepare-batch`) and decrypts/verifies (`/agent/eis/decode-batch`). **EIS keys never leave the server.** |
| Evaluate Pass / Fail | QA Pariksha server (`/evaluate-api-testcases`) — unchanged |

> The backend must have the agent endpoints installed first — see `backend_changes/README.md`.

---

## 1. Prerequisites (developer PC, Windows)

- **Node.js 20 LTS or newer**: https://nodejs.org (check with `node -v`)
- The PC must be able to reach the **QA Pariksha backend** and the **EIS UAT gateway** (`eissiuat.sbi.co.in`).
- Behind the bank proxy, configure npm first:
  ```bat
  npm config set proxy http://<proxy>:<port>
  npm config set https-proxy http://<proxy>:<port>
  ```
  If GitHub downloads are blocked, `npm install` cannot fetch the Electron binary. Set a mirror your network allows:
  `set ELECTRON_MIRROR=https://<internal-mirror>/electron/`

## 2. Install and run (development)

```bat
cd qa-pariksha-agent
npm install
npm run dev
```
`npm run dev` starts the Vite dev server and opens the app with DevTools.

On the login screen, click the **⚙ gear** and set the **QA Pariksha server URL**: the backend base URL, e.g. `https://<backend-host>:1000`, without `/api/...`. Click **Test connection**; it should list the allowed EIS host(s).

You can also set the default before starting: `set QA_PARIKSHA_SERVER_URL=https://<backend-host>:1000`

## 3. Build the Windows installer

```bat
npm run dist
```
Output: `release\QA-Pariksha-Agent-Setup-1.0.0.exe`. Give this file to testers. They install it, open **QA Pariksha Agent**, set the server URL once (⚙), and sign in.

Optional before wide rollout:
- **Code signing:** without it, Windows SmartScreen warns "unknown publisher". With the bank's code-signing certificate, set `CSC_LINK` / `CSC_KEY_PASSWORD` before `npm run dist`.
- **Default server URL in the installer:** change `serverUrl` in `electron/lib/config.js`.
- **Icon:** put `build/icon.ico` (256×256) in the project; electron-builder picks it up.

## 4. Self-test without the UI (optional)

Runs the same main-process code as the app:
```bat
node electron\lib\selftest.js https://<backend-host>:1000 <username> <password> path\to\spec.json EIS_CHANNEL
```
The sequence is: login → generate → run (prepare → EIS from this PC → decode) → evaluate → refresh → logout. Without a spec file, it stops after login. Use this to confirm network access to EIS from a tester PC.

## 5. Settings (⚙)

| Setting | Default | Notes |
|---|---|---|
| Server URL | `http://localhost:1000` | Changing it signs you out |
| Parallel EIS calls | 8 | 1–32 |
| EIS timeout | 60 s | Same as the server-side run |
| Accept untrusted certificate | off | Only for EIS hosts the server allows. Prefer installing the bank root CA in Windows instead. |

Settings are stored in `%APPDATA%\QA Pariksha Agent\config.json`. The login token is stored encrypted with Windows DPAPI in `session.bin` in the same folder, so it's readable only by that Windows user on that PC.

## 6. How it works / security

- **React UI** (`src/`) has **no Node access** (`contextIsolation`, `sandbox`, no `nodeIntegration`). It can only call the small API in `electron/preload.js`.
- **All network calls happen in the main process** (`electron/lib/`), through Chromium's network stack. It uses the Windows certificate store and system proxy, and there's no CORS issue.
- **Auth is Bearer-only.** The JWT never reaches the page. `Set-Cookie` from the server is stripped. The token refreshes automatically at 80% of its lifetime, and if the session expires the app returns to login and keeps the work on screen.
- **Every IPC call is checked** to come from the app's own page. Navigation and new windows are blocked.
- **Excel files** use exactly the web app's format, so a file edited in one can be uploaded in the other.
- **Run results** have the same three columns and the same error texts as the server-side run, so evaluation and reports are identical.

## Project layout
```
electron/
  main.js            window, sessions, IPC handlers
  preload.js         API exposed to the UI (window.agent)
  lib/config.js      settings
  lib/tokenStore.js  encrypted token storage
  lib/qaClient.js    QA Pariksha API client
  lib/runPipeline.js prepare → EIS → decode, with concurrency, timeout, cancel
  lib/selftest.js    CLI self-test (not packaged)
  e2e.js             UI end-to-end test (not packaged)
src/
  App.tsx            screens + workflow state
  components/        LoginView, SettingsDialog, SpecPanel, PayloadTree, ResultsPanel
  excel.ts           Excel download / re-upload / report
```
