# QA Pariksha backend changes for the Desktop Agent

You need one new file, one replaced file, two lines in `main.py`, and three `.env` entries. No database migration is needed. Login, generate and evaluate are unchanged.

## 1. Add a new file
**`api/endpoints/v1/agent_api.py`** (included here). It provides:

| Endpoint | Auth | Purpose |
|---|---|---|
| `GET  /api/v1/testcase-generation/agent/client-config` | public | Allowed EIS hosts, batch limit, minimum agent version |
| `POST /api/v1/testcase-generation/agent/auth/refresh` | Bearer | New token for the current user; the old token is revoked |
| `POST /api/v1/testcase-generation/agent/eis/prepare-batch` | Bearer | Resolves the RRN, encrypts and signs each test case, and returns `{url, headers, body}` |
| `POST /api/v1/testcase-generation/agent/eis/decode-batch` | Bearer | Decrypts and verifies the raw EIS responses, and returns the Actual_Response text |

## 2. Replace a file
**`api/utils/eis_api_utils.py`** (included here). It's a refactor with the same behaviour. `call_eis_api()` is now built from two reusable functions, `prepare_eis_request()` and `decode_eis_response()`, which the new endpoints also use, so the server run and the agent run can never drift apart. `/run-api-testcases` keeps working exactly as before.

## 3. Edit `main.py` (2 lines)
Next to the other router imports:
```python
from api.endpoints.v1.agent_api import agent_router
```
Next to the other `app.include_router(...)` lines:
```python
app.include_router(agent_router)
```

## 4. Add to `.env`
```ini
# Hosts the server will sign EIS requests for, on behalf of the desktop agent (comma-separated)
EIS_ALLOWED_HOSTS=eissiuat.sbi.co.in
# Max test cases per prepare/decode call
AGENT_MAX_BATCH=500
# Agents older than this are told to update
AGENT_MIN_VERSION=1.0.0
```

## 5. Restart and check
```bat
curl http://<backend-host>:1000/api/v1/testcase-generation/agent/client-config
```
Expected: `{"min_agent_version":"1.0.0","eis_allowed_hosts":["eissiuat.sbi.co.in"],"max_batch":500,"token_expire_minutes":30}`

## Notes
- **No CORS change is needed.** The agent calls the backend from Electron's main process, not from a browser page.
- **Network:** tester PCs must reach the backend URL (port 1000, or wherever it's exposed) and the EIS UAT host.
- **Login lockout is per username and per client IP.** If many testers sit behind one NAT or proxy IP, one person's 5 wrong passwords can briefly lock the others out from that IP.
- **SSO is not supported in the agent yet** (password login only). The web SSO callback redirects to the web frontend with a cookie.
- **Accounts with `must_change_password`** are told to change it in the web app. The change-password endpoint only returns the new token as a cookie.
